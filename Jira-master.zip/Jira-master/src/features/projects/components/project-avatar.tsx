import {ProjectAvatarProps} from "@/types";
import Image from "next/image";
import {cn} from "@/lib/utils";
import {Avatar, AvatarFallback} from "@/components/ui/avatar";

function ProjectAvatar({image, name, className, fallbackClassName}: ProjectAvatarProps) {
    if (image) {
        return (
            <div className={cn('size-5 relative rounded-md overflow-hidden', className)}>
                <Image src={image} alt={name} fill className={'object-cover flex-shrink-0'}/>
            </div>
        );
    }

    return (
        <Avatar className={cn('size-5 rounded-md', className)}>
            <AvatarFallback className={cn('text-white bg-blue-600 font-semibold text-sm uppercase rounded-md', fallbackClassName)}>{name[0]}</AvatarFallback>
        </Avatar>
    );
}

export default ProjectAvatar;
