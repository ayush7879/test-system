import {useQuery} from "@tanstack/react-query";
import {client} from "@/lib/rpc";
import {UseGetTasksProps} from "@/types";

export const useGetTasks = ({workspaceId, projectId, status, search, assigneeId, dueDate}: UseGetTasksProps) => {
    const query = useQuery({
        queryKey: ['tasks', workspaceId, projectId, status, search, assigneeId, dueDate],
        queryFn: async () => {
            const response = await client.api.tasks.$get({
                query: {
                    workspaceId,
                    projectId: projectId ?? undefined,
                    status: status ?? undefined,
                    search: search ?? undefined,
                    assigneeId: assigneeId ?? undefined,
                    dueDate: dueDate ?? undefined,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch tasks');
            }

            const {data} = await response.json();

            return data;
        }
    });

    return query;
}
